# Preetham M S — Portfolio

A responsive single-page portfolio landing page based on the supplied resume.

## Run locally
Open `index.html` in a browser.

## Deploy to Vercel
Import this folder/repository into Vercel. No build command is required for the static HTML page.
